---
external help file: PostInstall-help.xml
online version: 
schema: 2.0.0
---

# Invoke-LtPoistInstall

## SYNOPSIS
Short description

## SYNTAX

```
Invoke-LtPoistInstall [[-OutputPath] <Object>] [[-ConfigData] <Object>]
```

## DESCRIPTION
Long description

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Example of how to use this cmdlet
```

### -------------------------- EXAMPLE 2 --------------------------
```
Another example of how to use this cmdlet
```

## PARAMETERS

### -OutputPath
Specifies the output path.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: 

Required: False
Position: 1
Default value: [IO.Path]::Combine($PSscriptRoot,'LtPostInstall')
Accept pipeline input: False
Accept wildcard characters: False
```

### -ConfigData
Specifies the config data.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: 

Required: False
Position: 2
Default value: [IO.Path]::Combine($PSscriptRoot,'LtPostInstall.psd1')
Accept pipeline input: False
Accept wildcard characters: False
```

## INPUTS

### Inputs to this cmdlet (if any)

## OUTPUTS

## NOTES

## RELATED LINKS

