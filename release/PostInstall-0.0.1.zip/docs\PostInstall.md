---
Module Name: PostInstall
Module Guid: 00000000-0000-0000-0000-000000000000
Download Help Link: https://github.com/sundmoon/PostInstall/release/PostInstall/docs/PostInstall.md
Help Version: 0.0.2
Locale: en-US
---

# PostInstall Module
## Description
Post installation DSC based tasks instead of using unatend.xml

## PostInstall Cmdlets
### [Invoke-LtPoistInstall](Invoke-LtPoistInstall.md)
Short description



